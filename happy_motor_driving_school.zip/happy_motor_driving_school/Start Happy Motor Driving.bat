@echo off
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    py -3 -m venv .venv
    if errorlevel 1 goto setup_error
)

if not exist ".venv\dependencies-installed" (
    .venv\Scripts\python.exe -m pip install -r requirements.txt
    if errorlevel 1 goto setup_error
    echo installed>".venv\dependencies-installed"
)

.venv\Scripts\python.exe app.py %*
if errorlevel 1 pause
exit /b

:setup_error
echo Setup failed. Install Python 3.10 or newer with the Python Launcher, then try again.
pause
exit /b 1
