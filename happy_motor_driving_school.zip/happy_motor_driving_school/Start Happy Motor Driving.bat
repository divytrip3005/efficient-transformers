@echo off
setlocal
cd /d "%~dp0"

if exist ".venv\Scripts\python.exe" (
    ".venv\Scripts\python.exe" -c "import sys; raise SystemExit(sys.version_info < (3,10))" >nul 2>&1
    if errorlevel 1 goto setup_error
)

if not exist ".venv\Scripts\python.exe" (
    call :create_venv
    if errorlevel 1 goto setup_error
)

if not exist ".venv\dependencies-installed" (
    .venv\Scripts\python.exe -m pip install -r requirements.txt
    if errorlevel 1 goto setup_error
    >".venv\dependencies-installed" echo installed
)

.venv\Scripts\python.exe app.py %*
if errorlevel 1 pause
exit /b

:create_venv
set "PYTHON_EXE="
for /f "delims=" %%P in ('where python 2^>nul') do (
    "%%P" -c "import sys; raise SystemExit(sys.version_info < (3,10))" >nul 2>&1
    if not errorlevel 1 if not defined PYTHON_EXE set "PYTHON_EXE=%%P"
)
if defined PYTHON_EXE goto use_python_path

py -3 -c "import sys; raise SystemExit(sys.version_info < (3,10))" >nul 2>&1
if errorlevel 1 exit /b 1
py -3 -m venv .venv
exit /b

:use_python_path
"%PYTHON_EXE%" -m venv .venv
exit /b

:setup_error
echo Setup failed. Install Python 3.10 or newer and ensure it is available on PATH or through the Python Launcher.
echo If this folder already has an old .venv, extract this ZIP to a new folder or rename that .venv first.
pause
exit /b 1
