# Happy Motor Driving Manager

A local single-computer dashboard for customer records, payments, seven cars, daily odometer readings, fuel refills, and A4 monthly reports. The Excel workbook is the data file and can be edited directly.

## Start with one click

Install Python 3.10 or newer once on the laptop, then extract this ZIP into a new, permanent folder. This package does not include a Python virtual environment or a saved workbook path from another computer. On first launch, the Windows launcher creates a fresh `.venv` using Python installed on that PC; internet access is needed to install `openpyxl`.

- **Windows:** double-click `Start Happy Motor Driving.bat`. To put an icon on the desktop, right-click the `.bat` file and choose **Send to → Desktop (create shortcut)**.
- **Linux:** run `bash start_happy_motor_driving.sh` once from a terminal. After that you can use the same launcher; desktop behavior depends on the Linux file manager.

At first launch, a file picker asks you to select the Excel workbook to use. Choose the workbook containing your records. The app remembers that path on this PC for future launches. If you cancel, it uses the workbook included in this folder. The app opens the dashboard in your browser automatically.

Keep the launcher window open while the system is running. Closing it stops the app.

To choose a different workbook later, stop the app and run `.venv/bin/python app.py --choose-data` on Linux, or `.venv\Scripts\python.exe app.py --choose-data` on Windows.

## Excel workbook

The included workbook is `data/happy_motor_driving.xlsx`. It contains `Settings`, `Cars`, `Instructors`, `Customers`, `Payments`, `Mileage`, and `Fuel` sheets. Use **Cars & instructors** in the app to edit each car's plate, model, transmission, learning price, service dates, battery-change date, and notes. Set the licence-making price there too. In the same section, add instructors or edit their name, mobile number, licence number, and active status. All these updates are saved in the matching Excel sheets. Mileage includes a monthly average km per logged day, calculated per car. Customer balances are represented by formulas in `Customers` and computed from the `Payments` ledger.

Close the workbook in Excel before adding records in the app. Make a backup copy of the `data` folder regularly. The app listens only on this computer (`127.0.0.1`); it is not exposed to other devices on your network.

## Starter values to replace

The initial per-car learning prices (₹4,000) and licence-making price (₹1,500) are examples, not confirmed school prices. The three instructor names, seven models, and `SAMPLE-01` through `SAMPLE-07` license plates are also placeholders. Update these in Cars & instructors before relying on the records for business use.

## Reports and entry rules

- A mileage entry calculates distance as ending odometer minus starting odometer. Add one entry per car per day; the monthly average is total kilometres divided by days with a mileage entry.
- Record every refill with litres and amount paid. Monthly totals are calculated from these fuel entries.
- Monthly vehicle use and fuel reports can be printed from the browser using **Print A4**; choose “Save as PDF” in the print dialog if you want a file.
- A new customer uses the selected car's learning price, plus the current licence-making price if selected. Existing customers keep the prices recorded when they were added.
