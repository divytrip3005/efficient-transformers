# Happy Motor Driving Manager

A local single-computer dashboard for customer records, payments, seven cars, daily odometer readings, fuel refills, and A4 monthly reports. The Excel workbook is the data file and can be edited directly.

## Start with one click

Install Python 3.10 or newer once on the laptop, then extract this folder somewhere permanent. The first launch needs internet access to install `openpyxl`.

- **Windows:** double-click `Start Happy Motor Driving.bat`. To put an icon on the desktop, right-click the `.bat` file and choose **Send to → Desktop (create shortcut)**.
- **Linux:** run `bash start_happy_motor_driving.sh` once from a terminal. After that you can use the same launcher; desktop behavior depends on the Linux file manager.

At first launch, a file picker asks you to select the Excel workbook to use. Choose the workbook containing your previous records. The app remembers that path for future launches. If you cancel, it uses the workbook included in this folder. The app opens the dashboard in your browser automatically.

Keep the launcher window open while the system is running. Closing it stops the app.

To choose a different workbook later, stop the app and run `.venv/bin/python app.py --choose-data` on Linux, or `.venv\Scripts\python.exe app.py --choose-data` on Windows.

## Excel workbook

The included workbook is `data/happy_motor_driving.xlsx`. It contains `Settings`, `Cars`, `Instructors`, `Customers`, `Payments`, `Mileage`, and `Fuel` sheets. The Cars sheet includes license plate, last/next service dates, battery change date, and maintenance notes. The Instructors sheet includes mobile and licence number. Mileage includes a monthly average km per logged day, calculated per car. Use Excel to update vehicle/instructor details and course prices. Customer balances are also represented by formulas in the Customers sheet and are computed by the app from the Payments ledger.

Close the workbook in Excel before adding records in the app. Make a backup copy of the `data` folder regularly. The app listens only on this computer (`127.0.0.1`); it is not exposed to other devices on your network.

## Starter values to replace

The initial fee values (₹4,000 for learning and ₹1,500 extra for licence assistance) are examples, not confirmed school prices. The three instructor names, seven models, and `SAMPLE-01` through `SAMPLE-07` license plates are also placeholders. Replace them in Excel before relying on the records for business use.

## Reports and entry rules

- A mileage entry calculates distance as ending odometer minus starting odometer. Add one entry per car per day; the monthly average is total kilometres divided by days with a mileage entry.
- Record every refill with litres and amount paid. Monthly totals are calculated from these fuel entries.
- Monthly vehicle use and fuel reports can be printed from the browser using **Print A4**; choose “Save as PDF” in the print dialog if you want a file.
- Each new customer uses the current prices in Settings. Existing customers keep the prices recorded when they were added.
