#!/usr/bin/env python3
"""Happy Motor Driving: a local, Excel-backed driving school manager."""

from __future__ import annotations

import json
import argparse
import mimetypes
import threading
import webbrowser
from datetime import date, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
BOOK_PATH = DATA_DIR / "happy_motor_driving.xlsx"
DATA_PATH_CONFIG = ROOT / ".happy_motor_data_path"
HOST = "127.0.0.1"
PORT = 8765
LOCK = threading.RLock()

SHEETS = {
    "Settings": ["Setting", "Value"],
    "Cars": [
        "Car ID", "Car Name", "Model", "License Plate", "Transmission",
        "Learning Course Price (INR)", "Last Service Date", "Next Service Due",
        "Battery Change Date", "Maintenance Notes", "Active",
    ],
    "Instructors": ["Instructor ID", "Name", "Mobile", "Licence Number", "Active"],
    "Customers": [
        "Customer ID", "Name", "Address", "Mobile", "Car ID", "Licence Required",
        "Learning Fee (INR)", "Licence Making Fee (INR)", "Total Fee (INR)",
        "Paid (INR)", "Remaining (INR)", "Created Date",
    ],
    "Payments": ["Payment ID", "Customer ID", "Date", "Amount (INR)", "Method", "Note"],
    "Mileage": [
        "Entry ID", "Date", "Car ID", "Instructor", "Start KM", "End KM",
        "KM Driven", "Average KM/Day", "Note",
    ],
    "Fuel": [
        "Entry ID", "Date", "Car ID", "Litres", "Amount (INR)",
        "Odometer KM", "Fuel Station", "Note",
    ],
}

# Clearly marked starter examples; replace these with the school's real details.
SAMPLE_CARS = [
    ("CAR-01", "Car 1", "Maruti Alto", "SAMPLE-01", "", 4000, None, None, None, "Replace sample details", "Yes"),
    ("CAR-02", "Car 2", "Maruti WagonR", "SAMPLE-02", "", 4000, None, None, None, "Replace sample details", "Yes"),
    ("CAR-03", "Car 3", "Maruti Swift", "SAMPLE-03", "", 4000, None, None, None, "Replace sample details", "Yes"),
    ("CAR-04", "Car 4", "Hyundai i10", "SAMPLE-04", "", 4000, None, None, None, "Replace sample details", "Yes"),
    ("CAR-05", "Car 5", "Tata Tiago", "SAMPLE-05", "", 4000, None, None, None, "Replace sample details", "Yes"),
    ("CAR-06", "Car 6", "Maruti Celerio", "SAMPLE-06", "", 4000, None, None, None, "Replace sample details", "Yes"),
    ("CAR-07", "Car 7", "Hyundai Santro", "SAMPLE-07", "", 4000, None, None, None, "Replace sample details", "Yes"),
]
SAMPLE_INSTRUCTORS = [
    ("INS-01", "Raj Patel", "", "", "Yes"),
    ("INS-02", "Amit Shah", "", "", "Yes"),
    ("INS-03", "Nilesh Parmar", "", "", "Yes"),
]
DEFAULT_SETTINGS = [
    ("School Name", "Happy Motor Driving"),
    ("Owner Name", "Kaushal Trivedi"),
    ("Phone", "9879575412"),
    ("Default Learning Fee INR", 4000),
    ("Licence Making Price INR", 1500),
    ("Currency", "INR"),
]


def _style_sheet(ws):
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="173B57")
        cell.alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 25
    for col in ws.columns:
        letter = get_column_letter(col[0].column)
        width = min(max(max(len(str(c.value or "")) for c in col) + 2, 14), 34)
        ws.column_dimensions[letter].width = width
        if str(col[0].value or "") in ("Last Service Date", "Next Service Due", "Battery Change Date", "Date"):
            for cell in col[1:]:
                cell.number_format = "yyyy-mm-dd"
        if str(col[0].value or "") == "Learning Course Price (INR)":
            for cell in col[1:]:
                cell.number_format = '₹#,##0.00'


def _save(wb):
    BOOK_PATH.parent.mkdir(parents=True, exist_ok=True)
    for ws in wb.worksheets:
        _style_sheet(ws)
    wb.save(BOOK_PATH)


def ensure_workbook():
    BOOK_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not BOOK_PATH.exists():
        wb = Workbook()
        wb.remove(wb.active)
        for name, headers in SHEETS.items():
            wb.create_sheet(name).append(headers)
        for row in DEFAULT_SETTINGS:
            wb["Settings"].append(row)
        for row in SAMPLE_CARS:
            wb["Cars"].append(row)
        for row in SAMPLE_INSTRUCTORS:
            wb["Instructors"].append(row)
        _save(wb)
        return

    # Add new columns in place, mapping old headers and preserving every row.
    wb = load_workbook(BOOK_PATH, data_only=False)
    changed = False
    aliases = {
        "Cars": {"Registration": "License Plate", "Licence Plate": "License Plate"},
        "Customers": {"Licence Fee (INR)": "Licence Making Fee (INR)"},
    }
    setting_aliases = {
        "Learning Fee INR": "Default Learning Fee INR",
        "Licence Fee INR": "Licence Making Price INR",
    }
    for name, headers in SHEETS.items():
        if name not in wb.sheetnames:
            wb.create_sheet(name).append(headers)
            changed = True
            continue
        ws = wb[name]
        old_headers = [str(c.value) if c.value is not None else "" for c in ws[1]]
        mapped_headers = [aliases.get(name, {}).get(h, h) for h in old_headers]
        extras = [h for h in mapped_headers if h and h not in headers]
        target_headers = headers + extras
        settings_need_rename = name == "Settings" and any(
            row[0] in setting_aliases for row in ws.iter_rows(min_row=2, values_only=True)
            if row[0] is not None
        )
        if old_headers == target_headers and not settings_need_rename:
            continue
        saved_rows = []
        for values in ws.iter_rows(min_row=2, values_only=True):
            if not any(value is not None for value in values):
                continue
            record = {h: value for h, value in zip(mapped_headers, values) if h}
            if name == "Settings" and record.get("Setting") in setting_aliases:
                record["Setting"] = setting_aliases[record["Setting"]]
            if name == "Cars" and not record.get("Learning Course Price (INR)"):
                current_settings = _setting_map(wb)
                fallback = current_settings.get("Default Learning Fee INR", current_settings.get("Learning Fee INR", 4000))
                record["Learning Course Price (INR)"] = fallback
            if name == "Mileage" and record.get("Date"):
                try:
                    record["Date"] = date.fromisoformat(str(record["Date"])[:10])
                except ValueError:
                    pass
            saved_rows.append([record.get(h) for h in target_headers])
        ws.delete_rows(1, ws.max_row)
        ws.append(target_headers)
        for row in saved_rows:
            ws.append(row)
        changed = True
    if changed:
        _write_formulas(wb)
        _save(wb)


def _workbook(write=False):
    ensure_workbook()
    return load_workbook(BOOK_PATH, data_only=False)


def _rows(ws):
    return [dict(zip(SHEETS[ws.title], values)) for values in ws.iter_rows(min_row=2, values_only=True)
            if any(value is not None for value in values)]


def _iso(value):
    if isinstance(value, (date, datetime)):
        return value.isoformat()[:10]
    if value is None:
        return ""
    return str(value)[:10]


def _number(value, label, allow_zero=True):
    try:
        result = float(value)
    except (TypeError, ValueError):
        raise ValueError(f"Enter a valid {label}.")
    if result < 0 or (not allow_zero and result == 0):
        raise ValueError(f"{label.capitalize()} must be { 'greater than' if not allow_zero else 'at least'} zero.")
    return result


def _setting_map(wb):
    return {str(row[0]): row[1] for row in wb["Settings"].iter_rows(min_row=2, values_only=True)
            if row[0] is not None}


def _id(ws, prefix):
    numbers = []
    for row in ws.iter_rows(min_row=2, values_only=True):
        value = row[0]
        if isinstance(value, str) and value.startswith(prefix):
            try:
                numbers.append(int(value[len(prefix):]))
            except ValueError:
                pass
    return f"{prefix}{max(numbers, default=0) + 1:05d}"


def _write_formulas(wb):
    ws = wb["Customers"]
    for row in range(2, ws.max_row + 1):
        if not ws.cell(row, 1).value:
            continue
        ws.cell(row, 9, f"=G{row}+IF(F{row}=\"Yes\",H{row},0)")
        ws.cell(row, 10, f"=SUMIF(Payments!$B:$B,A{row},Payments!$D:$D)")
        ws.cell(row, 11, f"=MAX(0,I{row}-J{row})")
        for col in (7, 8, 9, 10, 11):
            ws.cell(row, col).number_format = '₹#,##0.00'
    mileage = wb["Mileage"]
    for row in range(2, mileage.max_row + 1):
        if not mileage.cell(row, 1).value:
            continue
        mileage.cell(row, 8,
            f'=IFERROR(AVERAGEIFS($G:$G,$C:$C,C{row},$B:$B,">="&DATE(YEAR(B{row}),MONTH(B{row}),1),'
            f'$B:$B,"<"&EDATE(DATE(YEAR(B{row}),MONTH(B{row}),1),1)),0)')
        mileage.cell(row, 8).number_format = '0.0'


def _computed_customers(wb):
    settings = _setting_map(wb)
    paid_by_id = {}
    for row in _rows(wb["Payments"]):
        paid_by_id[row["Customer ID"]] = paid_by_id.get(row["Customer ID"], 0) + float(row["Amount (INR)"] or 0)
    result = []
    for row in _rows(wb["Customers"]):
        learning = float(row["Learning Fee (INR)"] or 0)
        licence_fee = float(row["Licence Making Fee (INR)"] or 0) if row["Licence Required"] == "Yes" else 0
        total = learning + licence_fee
        paid = paid_by_id.get(row["Customer ID"], 0)
        row.update({"Learning Fee (INR)": learning, "Licence Making Fee (INR)": licence_fee,
                    "Total Fee (INR)": total, "Paid (INR)": paid,
                    "Remaining (INR)": max(0, total - paid),
                    "Created Date": _iso(row["Created Date"])})
        result.append(row)
    return result


def _monthly_report(wb, month):
    mileage = _rows(wb["Mileage"])
    fuel = _rows(wb["Fuel"])
    cars = _rows(wb["Cars"])
    report = []
    for car in cars:
        car_id = car["Car ID"]
        trips = [r for r in mileage if r["Car ID"] == car_id and _iso(r["Date"]).startswith(month)]
        refills = [r for r in fuel if r["Car ID"] == car_id and _iso(r["Date"]).startswith(month)]
        km = sum(float(r["KM Driven"] or 0) for r in trips)
        days_logged = len({_iso(r["Date"]) for r in trips})
        report.append({
            "carId": car_id, "name": car["Car Name"], "model": car["Model"],
            "registration": car["License Plate"],
            "km": round(km, 1),
            "avgKmPerDay": round(km / days_logged, 1) if days_logged else 0,
            "daysLogged": days_logged,
            "trips": len(trips),
            "litres": round(sum(float(r["Litres"] or 0) for r in refills), 2),
            "fuelCost": round(sum(float(r["Amount (INR)"] or 0) for r in refills), 2),
            "refills": len(refills),
        })
    return report


def get_data(month=None):
    month = month or date.today().strftime("%Y-%m")
    with LOCK:
        wb = _workbook()
        settings = _setting_map(wb)
        customers = _computed_customers(wb)
        payments = _rows(wb["Payments"])
        mileage = _rows(wb["Mileage"])
        fuel = _rows(wb["Fuel"])
        for collection in (payments, mileage, fuel):
            for row in collection:
                for key, value in row.items():
                    if key == "Date":
                        row[key] = _iso(value)
        monthly_averages = {}
        for row in mileage:
            month_key = (row["Car ID"], row["Date"][:7])
            total, days = monthly_averages.setdefault(month_key, [0.0, set()])
            monthly_averages[month_key][0] += float(row["KM Driven"] or 0)
            days.add(row["Date"])
        for row in mileage:
            total, days = monthly_averages[(row["Car ID"], row["Date"][:7])]
            row["Average KM/Day"] = round(total / len(days), 1) if days else 0
        report = _monthly_report(wb, month)
        month_payments = [p for p in payments if p["Date"].startswith(month)]
        cars = _rows(wb["Cars"])
        for car in cars:
            for field in ("Last Service Date", "Next Service Due", "Battery Change Date"):
                car[field] = _iso(car[field])
        return {
            "settings": settings,
            "cars": cars,
            "instructors": _rows(wb["Instructors"]),
            "customers": customers,
            "payments": list(reversed(payments[-50:])),
            "mileage": list(reversed(mileage[-50:])),
            "fuel": list(reversed(fuel[-50:])),
            "report": report,
            "summary": {
                "customers": len(customers),
                "outstanding": round(sum(c["Remaining (INR)"] for c in customers), 2),
                "collected": round(sum(float(p["Amount (INR)"] or 0) for p in month_payments), 2),
                "km": round(sum(c["km"] for c in report), 1),
                "fuelCost": round(sum(c["fuelCost"] for c in report), 2),
            },
            "month": month,
            "workbook": str(BOOK_PATH),
        }


def _append_payment(wb, customer_id, day, amount, method, note):
    wb["Payments"].append([_id(wb["Payments"], "PAY-"), customer_id, day, amount, method, note])


def _handle_post(path, body):
    with LOCK:
        wb = _workbook()
        if path == "/api/customer":
            name = str(body.get("name", "")).strip()
            address = str(body.get("address", "")).strip()
            mobile = str(body.get("mobile", "")).strip()
            car_id = str(body.get("carId", "")).strip()
            licence = "Yes" if body.get("licence") else "No"
            if not name or not address or not mobile or not car_id:
                raise ValueError("Name, address, mobile number, and car choice are required.")
            car = next((row for row in _rows(wb["Cars"]) if row["Car ID"] == car_id and row["Active"] == "Yes"), None)
            if car is None:
                raise ValueError("Choose one of the active cars in the fleet.")
            settings = _setting_map(wb)
            learning = _number(
                car.get("Learning Course Price (INR)") or settings.get("Default Learning Fee INR", 0),
                "learning fee", allow_zero=False,
            )
            licence_fee = _number(settings.get("Licence Making Price INR", 0), "licence-making price")
            customer_id = _id(wb["Customers"], "CUS-")
            total = learning + (licence_fee if licence == "Yes" else 0)
            initial = _number(body.get("initialPayment", 0), "initial payment")
            if initial > total:
                raise ValueError("Initial payment cannot be greater than the course total.")
            wb["Customers"].append([customer_id, name, address, mobile, car_id, licence,
                                   learning, licence_fee, None, None, None, date.today().isoformat()])
            if initial:
                _append_payment(wb, customer_id, body.get("date") or date.today().isoformat(),
                                initial, str(body.get("method", "Cash")), "Initial deposit")
        elif path == "/api/car":
            car_id = str(body.get("carId", "")).strip()
            ws = wb["Cars"]
            header_map = {str(cell.value): cell.column for cell in ws[1] if cell.value is not None}
            row_num = next((r for r in range(2, ws.max_row + 1) if ws.cell(r, header_map["Car ID"]).value == car_id), None)
            if row_num is None:
                raise ValueError("Choose a valid car to update.")
            transmission = str(body.get("transmission", "")).strip()
            if transmission not in ("Manual", "Automatic"):
                raise ValueError("Choose Manual or Automatic transmission.")
            learning = _number(body.get("learningPrice"), "learning-course price", allow_zero=False)
            updates = {
                "Car Name": str(body.get("carName", "")).strip(),
                "Model": str(body.get("model", "")).strip(),
                "License Plate": str(body.get("licensePlate", "")).strip(),
                "Transmission": transmission,
                "Learning Course Price (INR)": learning,
                "Maintenance Notes": str(body.get("maintenanceNotes", "")).strip(),
                "Active": "Yes" if body.get("active") else "No",
            }
            for key, body_key in (("Last Service Date", "lastService"),
                                  ("Next Service Due", "nextService"),
                                  ("Battery Change Date", "batteryChange")):
                raw = str(body.get(body_key, "")).strip()
                if raw:
                    try:
                        updates[key] = date.fromisoformat(raw)
                    except ValueError:
                        raise ValueError(f"Enter a valid {key.lower()}.")
                else:
                    updates[key] = None
            if not updates["Car Name"] or not updates["Model"] or not updates["License Plate"]:
                raise ValueError("Car name, model, and license plate are required.")
            for key, value in updates.items():
                ws.cell(row_num, header_map[key], value)
        elif path == "/api/settings":
            licence_price = _number(body.get("licencePrice"), "licence-making price")
            ws = wb["Settings"]
            found = False
            for row in range(2, ws.max_row + 1):
                if ws.cell(row, 1).value == "Licence Making Price INR":
                    ws.cell(row, 2, licence_price)
                    found = True
                    break
            if not found:
                ws.append(["Licence Making Price INR", licence_price])
        elif path == "/api/instructor":
            ws = wb["Instructors"]
            header_map = {str(cell.value): cell.column for cell in ws[1] if cell.value is not None}
            instructor_id = str(body.get("instructorId", "NEW")).strip()
            name = str(body.get("name", "")).strip()
            if not name:
                raise ValueError("Instructor name is required.")
            mobile = str(body.get("mobile", "")).strip()
            licence_number = str(body.get("licenceNumber", "")).strip()
            active = "Yes" if body.get("active") else "No"
            if instructor_id == "NEW":
                instructor_id = _id(ws, "INS-")
                ws.append([instructor_id, name, mobile, licence_number, active])
            else:
                row_num = next((r for r in range(2, ws.max_row + 1)
                                if ws.cell(r, header_map["Instructor ID"]).value == instructor_id), None)
                if row_num is None:
                    raise ValueError("Choose a valid instructor to update.")
                for key, value in (("Name", name), ("Mobile", mobile),
                                   ("Licence Number", licence_number), ("Active", active)):
                    ws.cell(row_num, header_map[key], value)
        elif path == "/api/payment":
            customer_id = str(body.get("customerId", ""))
            customers = _computed_customers(wb)
            customer = next((c for c in customers if c["Customer ID"] == customer_id), None)
            if customer is None:
                raise ValueError("Select a valid customer.")
            amount = _number(body.get("amount"), "payment", allow_zero=False)
            if amount > customer["Remaining (INR)"]:
                raise ValueError("Payment is greater than the customer's remaining balance.")
            _append_payment(wb, customer_id, body.get("date") or date.today().isoformat(), amount,
                            str(body.get("method", "Cash")), str(body.get("note", "")).strip())
        elif path == "/api/mileage":
            car_id = str(body.get("carId", ""))
            day = str(body.get("date", ""))
            start = _number(body.get("startKm"), "starting odometer")
            end = _number(body.get("endKm"), "ending odometer")
            if end < start:
                raise ValueError("Ending odometer must be equal to or greater than the starting odometer.")
            if not day or not any(r[0] == car_id for r in wb["Cars"].iter_rows(min_row=2, values_only=True)):
                raise ValueError("Choose a car and date for the mileage entry.")
            try:
                mileage_date = date.fromisoformat(day)
            except ValueError:
                raise ValueError("Enter a valid mileage date.")
            wb["Mileage"].append([_id(wb["Mileage"], "MIL-"), mileage_date, car_id,
                                  str(body.get("instructor", "")), start, end, end - start,
                                  None, str(body.get("note", "")).strip()])
        elif path == "/api/fuel":
            car_id = str(body.get("carId", ""))
            day = str(body.get("date", ""))
            litres = _number(body.get("litres"), "litres", allow_zero=False)
            amount = _number(body.get("amount"), "fuel amount", allow_zero=False)
            odometer = _number(body.get("odometerKm", 0), "odometer")
            if not day or not any(r[0] == car_id for r in wb["Cars"].iter_rows(min_row=2, values_only=True)):
                raise ValueError("Choose a car and date for the fuel entry.")
            wb["Fuel"].append([_id(wb["Fuel"], "FUEL-"), day, car_id, litres, amount,
                               odometer or None, str(body.get("station", "")).strip(),
                               str(body.get("note", "")).strip()])
        else:
            raise ValueError("Unknown action.")
        _write_formulas(wb)
        _save(wb)
    return {"ok": True}


class Handler(BaseHTTPRequestHandler):
    server_version = "HappyMotor/1.0"

    def log_message(self, fmt, *args):
        print("[Happy Motor] " + fmt % args)

    def _send(self, status, payload, content_type="application/json; charset=utf-8"):
        data = payload if isinstance(payload, bytes) else (
            json.dumps(payload, ensure_ascii=False, default=str).encode("utf-8")
            if content_type.startswith("application/json") else str(payload).encode("utf-8"))
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/":
            self._send(200, PAGE, "text/html; charset=utf-8")
        elif parsed.path == "/api/data":
            from urllib.parse import parse_qs
            month = parse_qs(parsed.query).get("month", [None])[0]
            try:
                self._send(200, get_data(month))
            except PermissionError:
                self._send(423, {"error": "Please close the Excel workbook while using the app, then refresh."})
            except Exception as exc:
                self._send(500, {"error": str(exc)})
        elif parsed.path == "/api/workbook":
            ensure_workbook()
            content_type = mimetypes.guess_type(BOOK_PATH.name)[0] or "application/octet-stream"
            self._send(200, BOOK_PATH.read_bytes(), content_type)
        else:
            self._send(404, {"error": "Not found"})

    def do_POST(self):
        parsed = urlparse(self.path)
        try:
            size = int(self.headers.get("Content-Length", "0"))
            if size > 100_000:
                raise ValueError("Request is too large.")
            body = json.loads(self.rfile.read(size) or b"{}")
            self._send(200, _handle_post(parsed.path, body))
        except ValueError as exc:
            self._send(400, {"error": str(exc)})
        except PermissionError:
            self._send(423, {"error": "Excel is using the workbook. Close it and try again."})
        except Exception as exc:
            self._send(500, {"error": str(exc)})


def _make_server():
    try:
        return ThreadingHTTPServer((HOST, PORT), Handler)
    except OSError as exc:
        print(f"Could not use local port {PORT} ({exc}); trying another available port.")
        return ThreadingHTTPServer((HOST, 0), Handler)


PAGE = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Happy Motor Driving | School Manager</title>
<style>
:root{--navy:#173b57;--ink:#1d2e3a;--muted:#6b7d89;--line:#dbe4e8;--paper:#fff;--bg:#f2f6f6;--teal:#147d75;--pale:#e8f4f2;--gold:#d79434;--red:#a7453e}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:15px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif}button,input,select,textarea{font:inherit}button{cursor:pointer}
.top{background:var(--navy);color:#fff;padding:19px max(24px,calc((100vw - 1220px)/2));display:flex;align-items:center;justify-content:space-between;gap:20px}.brand{font-size:21px;font-weight:750;letter-spacing:.1px}.owner{font-size:13px;opacity:.82;margin-top:2px}.top-right{display:flex;align-items:center;gap:12px}.phone{font-size:14px;opacity:.9}.layout{max-width:1220px;margin:24px auto;padding:0 20px;display:grid;grid-template-columns:205px 1fr;gap:22px}.nav{display:flex;flex-direction:column;gap:7px}.nav button{border:0;background:transparent;text-align:left;color:#536773;padding:12px 14px;border-radius:9px;font-weight:620}.nav button.active,.nav button:hover{background:#dcecea;color:#12695f}.content{min-width:0}.page-title{display:flex;align-items:flex-start;justify-content:space-between;gap:15px;margin:0 0 18px}.page-title h1{font-size:25px;margin:0 0 3px}.sub{color:var(--muted);font-size:13px}.cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:18px}.card,.panel{background:var(--paper);border:1px solid var(--line);border-radius:12px;padding:17px;box-shadow:0 2px 8px #18394b08}.metric-label{color:var(--muted);font-size:13px}.metric{font-size:25px;font-weight:740;margin-top:6px}.panel{margin-bottom:16px}.panel h2{font-size:17px;margin:0 0 13px}.grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px}.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.field{display:flex;flex-direction:column;gap:5px}.field.full{grid-column:1/-1}.field label{font-size:12px;font-weight:650;color:#536773}.field input,.field select,.field textarea,.toolbar input,.toolbar select{width:100%;border:1px solid #cdd9de;border-radius:7px;background:#fff;padding:9px 10px;color:var(--ink)}.field textarea{min-height:65px;resize:vertical}.check{display:flex;gap:9px;align-items:center;padding-top:23px}.check input{width:auto}.btn{border:0;border-radius:7px;padding:9px 13px;background:var(--teal);color:#fff;font-weight:650}.btn.secondary{background:#e5edef;color:#294554}.btn.outline{background:#fff;color:var(--teal);border:1px solid #a9cbc6}.btn.small{padding:6px 9px;font-size:12px}.toolbar{display:flex;align-items:end;justify-content:space-between;gap:10px;margin-bottom:13px}.toolbar .field{min-width:170px}.table-wrap{overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px}th{text-align:left;color:#617580;font-weight:650;font-size:11px;text-transform:uppercase;letter-spacing:.04em;padding:9px;border-bottom:1px solid var(--line);white-space:nowrap}td{padding:10px 9px;border-bottom:1px solid #edf1f2;vertical-align:top}tr:last-child td{border-bottom:0}.pill{display:inline-block;border-radius:20px;padding:3px 8px;background:var(--pale);color:#176d64;font-size:11px;font-weight:650}.balance{color:var(--red);font-weight:680}.muted{color:var(--muted)}.notice{border:1px solid #ead7a9;background:#fff8e6;color:#75591e;padding:10px 12px;border-radius:8px;font-size:12px;margin-bottom:15px}.error{color:var(--red);font-size:13px;margin-top:8px}.success{color:var(--teal);font-size:13px;margin-top:8px}.chart{display:flex;align-items:end;gap:9px;height:135px;border-bottom:1px solid var(--line);padding:8px 4px 0}.bar-item{flex:1;height:100%;display:flex;flex-direction:column;justify-content:end;align-items:center;gap:5px;min-width:32px}.bar{background:#66aaa2;border-radius:5px 5px 0 0;width:min(34px,80%);min-height:2px}.bar-label{font-size:10px;color:var(--muted);text-align:center;white-space:nowrap}.bar-value{font-size:10px;font-weight:650}.hidden{display:none!important}.toast{position:fixed;right:20px;bottom:20px;background:#183e54;color:white;padding:12px 16px;border-radius:9px;box-shadow:0 5px 20px #0002;z-index:5;max-width:350px}.right{margin-left:auto}.footer-note{font-size:12px;color:var(--muted);margin-top:11px}.actions{display:flex;gap:8px;align-items:center}.empty{padding:24px;text-align:center;color:var(--muted)}
@page{size:A4 portrait;margin:14mm}@media print{body{background:#fff;font-size:11px}.top{padding:0 0 12px;background:#fff;color:#111;border-bottom:2px solid #173b57}.owner,.phone{color:#333}.layout{display:block;max-width:none;margin:12px 0;padding:0}.nav,.no-print,.notice{display:none!important}.page-title h1{font-size:20px}.cards{grid-template-columns:repeat(4,1fr)}.card,.panel{box-shadow:none;border-color:#bbb;break-inside:avoid;padding:10px}.panel{margin-bottom:10px}th{color:#222}td,th{padding:6px}.chart{height:100px}.print-only{display:block!important}table{font-size:10px}}
@media(max-width:850px){.layout{grid-template-columns:1fr}.nav{flex-direction:row;overflow:auto}.nav button{white-space:nowrap}.cards{grid-template-columns:repeat(2,1fr)}.grid2{grid-template-columns:1fr}}@media(max-width:520px){.top{padding:15px 16px}.phone{display:none}.layout{margin:16px auto;padding:0 12px}.cards{gap:8px}.card{padding:12px}.metric{font-size:20px}.form-grid{grid-template-columns:1fr}.field.full{grid-column:auto}.page-title{align-items:center}}
</style></head><body>
<header class="top"><div><div class="brand">Happy Motor Driving</div><div class="owner">School management · <span id="ownerName">Kaushal Trivedi</span></div></div><div class="top-right"><span class="phone">☎ <span id="schoolPhone">9879575412</span></span><a class="btn secondary no-print" href="/api/workbook" download="happy_motor_driving.xlsx">Download Excel</a></div></header>
<div class="layout"><nav class="nav no-print"><button class="active" data-page="dashboard">Overview</button><button data-page="customers">Customers & payments</button><button data-page="mileage">Daily mileage</button><button data-page="fuel">Fuel refills</button><button data-page="reports">Monthly reports</button><button data-page="fleet">Cars & instructors</button></nav>
<main class="content">
<section id="dashboard" class="view"><div class="page-title"><div><h1>Overview</h1><div class="sub">A quick look at your school this month.</div></div><div class="actions no-print"><input id="dashMonth" type="month" aria-label="Month"></div></div><div class="notice">Starter car prices and vehicle details are examples. Update car details and prices in Cars & pricing before using for new customers. Close Excel while saving entries in this app.</div><div class="cards" id="dashboardCards"></div><div class="grid2"><div class="panel"><h2>Monthly car use</h2><div id="dashChart"></div></div><div class="panel"><h2>Quick links</h2><p class="sub">Add customers, record odometer readings each day, and enter each fuel refill. Monthly reports summarize those logs per car.</p><div class="actions no-print"><button class="btn" onclick="showPage('customers')">Add a customer</button><button class="btn secondary" onclick="showPage('mileage')">Log mileage</button></div><div class="footer-note">Excel workbook: <span id="bookPath"></span></div></div></div></section>

<section id="customers" class="view hidden"><div class="page-title"><div><h1>Customers & payments</h1><div class="sub">The selected car's learning price and optional licence-making price determine the course total.</div></div></div><div class="grid2"><div class="panel"><h2>Add customer</h2><form id="customerForm" class="form-grid"><div class="field"><label>Customer name *</label><input name="name" required></div><div class="field"><label>Mobile number *</label><input name="mobile" required inputmode="tel"></div><div class="field full"><label>Address *</label><textarea name="address" required></textarea></div><div class="field"><label>Car choice *</label><select name="carId" id="customerCar" required></select></div><label class="check"><input name="licence" type="checkbox"><span>Licence making required (extra fee)</span></label><div class="field full sub" id="customerPricePreview"></div><div class="field"><label>Initial deposit (₹)</label><input name="initialPayment" type="number" min="0" step="0.01" value="0"></div><div class="field"><label>Payment method</label><select name="method"><option>Cash</option><option>UPI</option><option>Bank transfer</option><option>Other</option></select></div><div class="field full"><button class="btn">Save customer</button><div class="form-msg"></div></div></form></div><div class="panel"><h2>Record a payment</h2><form id="paymentForm" class="form-grid"><div class="field full"><label>Customer *</label><select name="customerId" id="paymentCustomer" required></select></div><div class="field"><label>Amount (₹) *</label><input name="amount" type="number" min="0.01" step="0.01" required></div><div class="field"><label>Date *</label><input name="date" type="date" required></div><div class="field"><label>Method</label><select name="method"><option>Cash</option><option>UPI</option><option>Bank transfer</option><option>Other</option></select></div><div class="field"><label>Note</label><input name="note" placeholder="Optional"></div><div class="field full"><button class="btn">Save payment</button><div class="form-msg"></div></div></form></div></div><div class="panel"><h2>Customer balances</h2><div class="table-wrap" id="customerTable"></div></div><div class="panel"><h2>Recent payments</h2><div class="table-wrap" id="paymentsTable"></div></div></section>

<section id="mileage" class="view hidden"><div class="page-title"><div><h1>Daily mileage</h1><div class="sub">Enter the odometer at the start and end of the day's use. Kilometres are calculated automatically.</div></div></div><div class="panel"><h2>Log odometer readings</h2><form id="mileageForm" class="form-grid"><div class="field"><label>Date *</label><input name="date" type="date" required></div><div class="field"><label>Car *</label><select name="carId" class="car-select" required></select></div><div class="field"><label>Instructor</label><select name="instructor" class="instructor-select"></select></div><div class="field"><label>Starting odometer (km) *</label><input name="startKm" type="number" min="0" step="0.1" required></div><div class="field"><label>Ending odometer (km) *</label><input name="endKm" type="number" min="0" step="0.1" required></div><div class="field"><label>Note</label><input name="note" placeholder="Optional"></div><div class="field full"><button class="btn">Save mileage</button><div class="form-msg"></div></div></form></div><div class="panel"><h2>Latest mileage entries</h2><div id="mileageTable" class="table-wrap"></div></div></section>

<section id="fuel" class="view hidden"><div class="page-title"><div><h1>Fuel refills</h1><div class="sub">Record each petrol/fuel refill; monthly totals are grouped by car.</div></div></div><div class="panel"><h2>Log a refill</h2><form id="fuelForm" class="form-grid"><div class="field"><label>Date *</label><input name="date" type="date" required></div><div class="field"><label>Car *</label><select name="carId" class="car-select" required></select></div><div class="field"><label>Fuel added (litres) *</label><input name="litres" type="number" min="0.01" step="0.01" required></div><div class="field"><label>Amount paid (₹) *</label><input name="amount" type="number" min="0.01" step="0.01" required></div><div class="field"><label>Odometer at refill (km)</label><input name="odometerKm" type="number" min="0" step="0.1"></div><div class="field"><label>Fuel station</label><input name="station" placeholder="Optional"></div><div class="field full"><label>Note</label><input name="note" placeholder="Optional"></div><div class="field full"><button class="btn">Save refill</button><div class="form-msg"></div></div></form></div><div class="panel"><h2>Latest fuel entries</h2><div id="fuelTable" class="table-wrap"></div></div></section>

<section id="reports" class="view hidden"><div class="page-title"><div><h1>Monthly reports</h1><div class="sub">Choose a month, then print this page or save it as a PDF on A4 paper.</div></div><div class="actions no-print"><input id="reportMonth" type="month" aria-label="Report month"><button class="btn" onclick="window.print()">Print A4</button></div></div><div class="cards" id="reportCards"></div><div class="panel"><h2 id="reportHeading">Vehicle usage and fuel summary</h2><div id="reportChart"></div><div class="table-wrap" id="reportTable"></div><div class="footer-note">Kilometres are summed from daily starting/ending odometer entries. Fuel totals are based on refill entries recorded.</div></div><div class="panel"><h2>Monthly payment collection</h2><div id="monthlyPayments"></div></div></section>

<section id="fleet" class="view hidden"><div class="page-title"><div><h1>Cars & instructors</h1><div class="sub">Manage cars, course prices, and instructor contact/licence details. Updates are saved to Excel.</div></div></div><div class="panel"><h2>Edit car</h2><form id="carForm" class="form-grid"><div class="field full"><label>Select car *</label><select name="carId" id="editCarSelect" required></select></div><div class="field"><label>Car name *</label><input name="carName" required></div><div class="field"><label>Model *</label><input name="model" required></div><div class="field"><label>Licence plate *</label><input name="licensePlate" required></div><div class="field"><label>Transmission *</label><select name="transmission" required><option value="">Choose transmission</option><option>Manual</option><option>Automatic</option></select></div><div class="field"><label>Learning-course price (₹) *</label><input name="learningPrice" type="number" min="0.01" step="0.01" required></div><div class="field"><label>Last service date</label><input name="lastService" type="date"></div><div class="field"><label>Next service due</label><input name="nextService" type="date"></div><div class="field"><label>Battery change date</label><input name="batteryChange" type="date"></div><label class="check"><input name="active" type="checkbox"><span>Available for customer bookings</span></label><div class="field full"><label>Maintenance notes</label><textarea name="maintenanceNotes"></textarea></div><div class="field full"><button class="btn">Save car details</button><div class="form-msg"></div></div></form></div><div class="panel"><h2>Set licence-making price</h2><form id="licencePriceForm" class="form-grid"><div class="field"><label>Licence-making price added to a customer (₹)</label><input name="licencePrice" type="number" min="0" step="0.01" required></div><div class="field check"><button class="btn">Save price</button></div><div class="field full sub">This charge is added only when licence making is selected. Changing it affects new customers; existing customer prices stay unchanged.<div class="form-msg"></div></div></form></div><div class="panel"><h2>Fleet details</h2><div class="table-wrap" id="carsTable"></div></div><div class="panel"><h2>Manage instructors</h2><form id="instructorForm" class="form-grid"><div class="field full"><label>Select instructor</label><select name="instructorId" id="editInstructorSelect" required></select></div><div class="field"><label>Instructor name *</label><input name="name" required></div><div class="field"><label>Mobile number</label><input name="mobile" type="tel" autocomplete="tel"></div><div class="field"><label>Licence number</label><input name="licenceNumber" autocomplete="off"></div><label class="check"><input name="active" type="checkbox"><span>Active and available for assignments</span></label><div class="field full"><button class="btn" id="saveInstructorButton">Save instructor details</button><div class="form-msg"></div></div></form></div><div class="panel"><h2>Instructor list</h2><div class="table-wrap" id="instructorsTable"></div></div></section>
</main></div><div id="toast" class="toast hidden"></div>
<script>
let DATA=null;const INR=new Intl.NumberFormat('en-IN',{style:'currency',currency:'INR',maximumFractionDigits:0});const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}function money(v){return INR.format(Number(v||0))}function carName(id){const c=DATA.cars.find(x=>x['Car ID']===id);return c?`${c['Car Name']} · ${c.Model}`:id||'—'}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.remove('hidden');setTimeout(()=>t.classList.add('hidden'),3500)}function showPage(id){$$('.view').forEach(x=>x.classList.toggle('hidden',x.id!==id));$$('.nav button').forEach(x=>x.classList.toggle('active',x.dataset.page===id));if(id==='reports')load($('#reportMonth').value||DATA?.month)}
$$('.nav button').forEach(b=>b.onclick=()=>showPage(b.dataset.page));
function table(headers,rows){if(!rows.length)return '<div class="empty">No records yet.</div>';return `<table><thead><tr>${headers.map(h=>`<th>${h[0]}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${headers.map(h=>`<td>${h[1](r)}</td>`).join('')}</tr>`).join('')}</tbody></table>`}
function options(){const cars=DATA.cars.filter(c=>c.Active==='Yes');const caropts=cars.map(c=>`<option value="${esc(c['Car ID'])}">${esc(c['Car Name'])} — ${esc(c.Model)} (${esc(c['License Plate'])}) · ${money(c['Learning Course Price (INR)']||DATA.settings['Default Learning Fee INR'])}</option>`).join('');$('#customerCar').innerHTML='<option value="">Choose a car</option>'+caropts;$$('.car-select').forEach(s=>s.innerHTML='<option value="">Choose a car</option>'+caropts);const editSelect=$('#editCarSelect');const previous=editSelect.value;editSelect.innerHTML=DATA.cars.map(c=>`<option value="${esc(c['Car ID'])}">${esc(c['Car ID'])} — ${esc(c['Car Name'])}</option>`).join('');if(DATA.cars.some(c=>c['Car ID']===previous))editSelect.value=previous;const ins=DATA.instructors.filter(i=>i.Active==='Yes');$$('.instructor-select').forEach(s=>s.innerHTML='<option value="">Choose instructor</option>'+ins.map(i=>`<option>${esc(i.Name)}</option>`).join(''));const instructorSelect=$('#editInstructorSelect');const oldInstructor=instructorSelect.value;instructorSelect.innerHTML='<option value="NEW">+ Add new instructor</option>'+DATA.instructors.map(i=>`<option value="${esc(i['Instructor ID'])}">${esc(i['Instructor ID'])} — ${esc(i.Name)}</option>`).join('');if([...instructorSelect.options].some(o=>o.value===oldInstructor))instructorSelect.value=oldInstructor;$('#paymentCustomer').innerHTML='<option value="">Choose customer</option>'+DATA.customers.filter(c=>c['Remaining (INR)']>0).map(c=>`<option value="${esc(c['Customer ID'])}">${esc(c.Name)} — balance ${money(c['Remaining (INR)'])}</option>`).join('')}
function fillCarEditor(){const car=DATA.cars.find(c=>c['Car ID']===$('#editCarSelect').value)||DATA.cars[0];if(!car)return;$('#editCarSelect').value=car['Car ID'];const f=$('#carForm').elements;f.carName.value=car['Car Name']||'';f.model.value=car.Model||'';f.licensePlate.value=car['License Plate']||'';f.transmission.value=car.Transmission||'';f.learningPrice.value=car['Learning Course Price (INR)']||DATA.settings['Default Learning Fee INR']||'';f.lastService.value=car['Last Service Date']||'';f.nextService.value=car['Next Service Due']||'';f.batteryChange.value=car['Battery Change Date']||'';f.maintenanceNotes.value=car['Maintenance Notes']||'';f.active.checked=car.Active==='Yes';$('#licencePriceForm').elements.licencePrice.value=DATA.settings['Licence Making Price INR']||0;updateCustomerPrice()}
function fillInstructorEditor(){const id=$('#editInstructorSelect').value;const instructor=DATA.instructors.find(i=>i['Instructor ID']===id);const f=$('#instructorForm').elements;f.instructorId.value=id||'NEW';f.name.value=instructor?.Name||'';f.mobile.value=instructor?.Mobile||'';f.licenceNumber.value=instructor?.['Licence Number']||'';f.active.checked=instructor?instructor.Active==='Yes':true;$('#saveInstructorButton').textContent=instructor?'Save instructor details':'Add instructor'}
function updateCustomerPrice(){if(!DATA)return;const car=DATA.cars.find(c=>c['Car ID']===$('#customerCar').value);if(!car){$('#customerPricePreview').textContent='Choose a car to see the course price.';return}const learning=Number(car['Learning Course Price (INR)']||DATA.settings['Default Learning Fee INR']||0);const licence=$('#customerForm').elements.licence.checked?Number(DATA.settings['Licence Making Price INR']||0):0;$('#customerPricePreview').textContent=`Learning: ${money(learning)}${licence?` · Licence making: ${money(licence)}`:''} · Total course price: ${money(learning+licence)}`}
function bars(el,items){const max=Math.max(1,...items.map(i=>Number(i.km)||0));el.innerHTML=`<div class="chart">${items.map(i=>`<div class="bar-item"><span class="bar-value">${esc(i.km)} km</span><div class="bar" style="height:${Math.max(2,Number(i.km)/max*80)}%" title="${esc(i.name)}: ${esc(i.km)} km"></div><span class="bar-label">${esc(i.name)}</span></div>`).join('')}</div>`}
function render(){if(!DATA)return;$('#ownerName').textContent=DATA.settings['Owner Name']||'Owner';$('#schoolPhone').textContent=DATA.settings.Phone||'';$('#bookPath').textContent=DATA.workbook;options();fillCarEditor();fillInstructorEditor();const s=DATA.summary;$('#dashboardCards').innerHTML=[['Customers',s.customers],['Collected this month',money(s.collected)],['Outstanding balance',money(s.outstanding)],['Fleet km this month',`${s.km} km`]].map(x=>`<div class="card"><div class="metric-label">${x[0]}</div><div class="metric">${x[1]}</div></div>`).join('');bars($('#dashChart'),DATA.report);
$('#customerTable').innerHTML=table([['Customer',r=>`<strong>${esc(r.Name)}</strong><br><span class="muted">${esc(r['Customer ID'])} · ${esc(r.Mobile)}</span>`],['Address',r=>esc(r.Address)],['Car',r=>esc(carName(r['Car ID']))],['Licence',r=>r['Licence Required']==='Yes'?'<span class="pill">Included</span>':'No'],['Course total',r=>money(r['Total Fee (INR)'])],['Paid',r=>money(r['Paid (INR)'])],['Remaining',r=>`<span class="balance">${money(r['Remaining (INR)'])}</span>`]],DATA.customers);
$('#paymentsTable').innerHTML=table([['Date',r=>esc(r.Date)],['Customer',r=>esc(DATA.customers.find(c=>c['Customer ID']===r['Customer ID'])?.Name||r['Customer ID'])],['Amount',r=>money(r['Amount (INR)'])],['Method',r=>esc(r.Method)],['Note',r=>esc(r.Note)]],DATA.payments);
$('#mileageTable').innerHTML=table([['Date',r=>esc(r.Date)],['Car',r=>esc(carName(r['Car ID']))],['Instructor',r=>esc(r.Instructor)],['Start km',r=>esc(r['Start KM'])],['End km',r=>esc(r['End KM'])],['Driven',r=>`${esc(r['KM Driven'])} km`],['Monthly avg / day',r=>`${esc(r['Average KM/Day'])} km`]],DATA.mileage);
$('#fuelTable').innerHTML=table([['Date',r=>esc(r.Date)],['Car',r=>esc(carName(r['Car ID']))],['Litres',r=>esc(r.Litres)],['Amount',r=>money(r['Amount (INR)'])],['Odometer',r=>r['Odometer KM']?`${esc(r['Odometer KM'])} km`:'—'],['Station',r=>esc(r['Fuel Station'])]],DATA.fuel);
$('#carsTable').innerHTML=table([['Car ID',r=>esc(r['Car ID'])],['Car',r=>esc(r['Car Name'])],['Model',r=>esc(r.Model)],['License plate',r=>esc(r['License Plate'])],['Transmission',r=>esc(r.Transmission)],['Learning price',r=>money(r['Learning Course Price (INR)'])],['Last service',r=>esc(r['Last Service Date'])],['Next service due',r=>esc(r['Next Service Due'])],['Battery changed',r=>esc(r['Battery Change Date'])],['Maintenance notes',r=>esc(r['Maintenance Notes'])],['Status',r=>esc(r.Active)]],DATA.cars);$('#instructorsTable').innerHTML=table([['Name',r=>esc(r.Name)],['Mobile',r=>esc(r.Mobile)],['Licence number',r=>esc(r['Licence Number'])],['Status',r=>esc(r.Active)]],DATA.instructors);
renderReport(DATA);}
function renderReport(d){const s=d.summary;$('#reportHeading').textContent=`Vehicle usage and fuel summary — ${d.month}`;$('#reportCards').innerHTML=[['Total kilometres',`${s.km} km`],['Fuel added',`${d.report.reduce((a,x)=>a+x.litres,0).toFixed(2)} L`],['Fuel spend',money(s.fuelCost)],['Payments collected',money(s.collected)]].map(x=>`<div class="card"><div class="metric-label">${x[0]}</div><div class="metric">${x[1]}</div></div>`).join('');bars($('#reportChart'),d.report);$('#reportTable').innerHTML=table([['Vehicle',r=>`<strong>${esc(r.name)}</strong><br><span class="muted">${esc(r.model)} · ${esc(r.registration)}</span>`],['Total use',r=>`${r.km} km · ${r.trips} logs`],['Average per day',r=>`${r.avgKmPerDay} km (${r.daysLogged} days logged)`],['Fuel added',r=>`${r.litres.toFixed(2)} L · ${r.refills} refills`],['Fuel cost',r=>money(r.fuelCost)]],d.report);const pays=d.payments.filter(p=>p.Date.startsWith(d.month));$('#monthlyPayments').innerHTML=table([['Date',r=>esc(r.Date)],['Customer',r=>esc(d.customers.find(c=>c['Customer ID']===r['Customer ID'])?.Name||r['Customer ID'])],['Amount',r=>money(r['Amount (INR)'])],['Method',r=>esc(r.Method)],['Note',r=>esc(r.Note)]],pays)}
async function load(month){try{const res=await fetch('/api/data'+(month?'?month='+encodeURIComponent(month):''));const d=await res.json();if(!res.ok)throw Error(d.error||'Could not load records');DATA=d;render();}catch(e){toast(e.message)}}
function todayISO(){const d=new Date();d.setMinutes(d.getMinutes()-d.getTimezoneOffset());return d.toISOString().slice(0,10)}
async function submit(form,path){const msg=form.querySelector('.form-msg');msg.textContent='';const body=Object.fromEntries(new FormData(form).entries());if(form.elements.licence)body.licence=form.elements.licence.checked;try{const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const j=await r.json();if(!r.ok)throw Error(j.error||'Could not save');form.reset();form.querySelectorAll('input[type=date]').forEach(x=>x.value=todayISO());msg.className='form-msg success';msg.textContent='Saved successfully.';await load($('#dashMonth').value||DATA.month);setTimeout(()=>msg.textContent='',4000)}catch(e){msg.className='form-msg error';msg.textContent=e.message}}
$('#customerForm').onsubmit=e=>{e.preventDefault();submit(e.currentTarget,'/api/customer')};$('#paymentForm').onsubmit=e=>{e.preventDefault();submit(e.currentTarget,'/api/payment')};$('#mileageForm').onsubmit=e=>{e.preventDefault();submit(e.currentTarget,'/api/mileage')};$('#fuelForm').onsubmit=e=>{e.preventDefault();submit(e.currentTarget,'/api/fuel')};
$('#customerCar').onchange=updateCustomerPrice;$('#customerForm').elements.licence.onchange=updateCustomerPrice;$('#editCarSelect').onchange=fillCarEditor;
$('#editInstructorSelect').onchange=fillInstructorEditor;
async function saveManagedForm(form,path){const msg=form.querySelector('.form-msg');msg.textContent='';const body=Object.fromEntries(new FormData(form).entries());if(form.elements.active)body.active=form.elements.active.checked;try{const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const result=await r.json();if(!r.ok)throw Error(result.error||'Could not save');msg.className='form-msg success';msg.textContent='Saved successfully.';await load($('#dashMonth').value||DATA.month);setTimeout(()=>msg.textContent='',4000)}catch(e){msg.className='form-msg error';msg.textContent=e.message}}
$('#carForm').onsubmit=e=>{e.preventDefault();saveManagedForm(e.currentTarget,'/api/car')};$('#licencePriceForm').onsubmit=e=>{e.preventDefault();saveManagedForm(e.currentTarget,'/api/settings')};
$('#instructorForm').onsubmit=e=>{e.preventDefault();saveManagedForm(e.currentTarget,'/api/instructor')};
function setDates(){const date=todayISO(),month=date.slice(0,7);$$('input[type=date]').forEach(x=>x.value=date);$('#dashMonth').value=month;$('#reportMonth').value=month}$('#dashMonth').onchange=e=>load(e.target.value);$('#reportMonth').onchange=e=>load(e.target.value);setDates();load($('#dashMonth').value);
</script></body></html>'''


def main():
    global BOOK_PATH
    parser = argparse.ArgumentParser(description="Happy Motor Driving local manager")
    parser.add_argument("--choose-data", action="store_true", help="choose a different Excel workbook")
    args = parser.parse_args()

    # Remember a workbook path selected on first launch; next launches reuse it.
    saved_path_valid = False
    if DATA_PATH_CONFIG.exists():
        try:
            saved_path = Path(DATA_PATH_CONFIG.read_text(encoding="utf-8").strip()).expanduser()
            if saved_path.is_file():
                BOOK_PATH = saved_path.resolve()
                saved_path_valid = True
        except OSError:
            pass
    if args.choose_data or not saved_path_valid:
        default_book = BOOK_PATH
        selected = ""
        try:
            import tkinter as tk
            from tkinter import filedialog
            root = tk.Tk()
            root.withdraw()
            try:
                root.attributes("-topmost", True)
            except tk.TclError:
                pass
            selected = filedialog.askopenfilename(
                parent=root,
                title="Choose Happy Motor Driving Excel workbook",
                initialdir=str(default_book.parent),
                filetypes=[("Excel workbook", "*.xlsx"), ("All files", "*.*")],
            )
            root.destroy()
        except Exception:
            try:
                selected = input(
                    f"Enter Excel workbook path, or press Enter to use {default_book}: "
                ).strip()
            except EOFError:
                selected = ""
        if selected:
            BOOK_PATH = Path(selected).expanduser().resolve()
        else:
            BOOK_PATH = default_book
        try:
            DATA_PATH_CONFIG.write_text(str(BOOK_PATH.resolve()), encoding="utf-8")
        except OSError as exc:
            print(f"Could not remember workbook path ({exc}); it can still be used this session.")

    ensure_workbook()
    print("Happy Motor Driving manager is ready.")
    print(f"Excel workbook: {BOOK_PATH}")
    print("Keep the workbook closed while entering records in the app. Press Ctrl+C to stop.")
    server = _make_server()
    app_url = f"http://{HOST}:{server.server_address[1]}"
    print(f"Open {app_url} in your browser.")
    threading.Timer(1.0, lambda: webbrowser.open(app_url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down Happy Motor Driving manager.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
