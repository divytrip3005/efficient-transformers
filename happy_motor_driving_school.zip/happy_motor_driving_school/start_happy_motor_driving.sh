#!/usr/bin/env bash
set -e
cd -- "$(dirname -- "$0")"

if [ ! -x ".venv/bin/python" ]; then
    python3 -m venv .venv
fi

if [ ! -f ".venv/dependencies-installed" ]; then
    .venv/bin/python -m pip install -r requirements.txt
    touch .venv/dependencies-installed
fi

exec .venv/bin/python app.py "$@"
